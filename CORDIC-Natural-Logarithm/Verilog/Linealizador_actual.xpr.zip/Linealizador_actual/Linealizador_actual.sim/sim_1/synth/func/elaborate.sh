#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2015.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 27fca5caba1447729beab1f3357ae31a -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L unisims_ver -L secureip --snapshot TB_LINEALIZADOR_func_synth xil_defaultlib.TB_LINEALIZADOR xil_defaultlib.glbl -log elaborate.log
